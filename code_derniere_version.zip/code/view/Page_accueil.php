<?php ob_start(); ?>
  <div id="scroll-spy"></div>

	<div id="container">
	    <div id="map"></div>
      <a href="/Hackathon/code"><img src="/Hackathon/code/img/Maps-Define-Location-icon.png" class="locate-icon" alt="Relocalisez"/></a>
	</div>
  <?php
    $parsed_json = json_decode(file_get_contents("http://api.wunderground.com/api/872e787884b6221c/forecast/lang:FR/q/-22,166.json"), true);
    echo "<img class='meteo' src='".$parsed_json['forecast']['simpleforecast']['forecastday'][0]['icon_url']."'/>";
  ?>
	<!-- Menu -->
	<a class="js-scrollTo" href="#more" style="text-decoration: none">
    <div id="top-icon" onclick="clickScroll();"><i class="fa fa-arrow-up" aria-hidden="true"></i></div>
  </a>
  <a class="js-scrollTo" href="#more">
    <nav>
        <ul>
            <li>
              <div class="flexdiv">
                <img src="/Hackathon/code/img/wind_<?php echo $niveauAir; ?>.png" class="<?php echo $niveauAir; ?>"><!-- <i class="fa fa-cloud green" aria-hidden="true"></i> -->
                <p>Air</p>
               </div>
            </li>
            <li>
              <div class="flexdiv">
                <img src="/Hackathon/code/img/fire_<?php echo $niveauFeu; ?>.png" class="<?php echo $niveauFeu; ?>">
                <p>Feu</p>
              </div>
            </li>
            <li>
              <div class="flexdiv">
                <img src="/Hackathon/code/img/swim_<?php echo $niveauBaignade ?>.png" class="<?php echo $niveauBaignade ?>">
                <p>Baignade</p>
              </div>
            </li>
        </ul>
    </nav>
  </a>

  <!-- #66717b  lightslategrey -->
  <div id="more">
  	<a href="/Hackathon/code/index.php/detail_air">
        <section>
            <div class="info">
                <h1><img src="/Hackathon/code/img/wind_<?php echo $niveauAir; ?>.png" class="<?php echo $niveauAir; ?>"> Qualité de l'air</h1>
                <span class="description"><a href="/Hackathon/code/index.php/detail_air"><i class="fa fa-info-circle infolink" aria-hidden="true"></i></a>
                  <?php 
                  switch ($niveauAir) {
                    case 'red':
                      echo "La qualité de l'air est <strong>mauvaise</strong>, 
                            <strong>au moins une</strong> concentration en éléments
                            toxiques <strong>dépasse</strong> du seuil critique.";
                      break;
                    case 'orange':
                      echo "La qualité de l'air est <strong>moyenne</strong>, 
                            <strong>au moins une</strong> concentration en éléments
                            toxiques <strong>se rapproche</strong> du seuil critique, aucune ne l'ayant atteinte.";
                      break;
                    
                    case 'green':
                      echo "Qualité de l'air <strong>bonne</strong>. <br/> 
                            Concentrations des éléments toxiques contenus
                            dans l'air <strong>en dessous</strong> du seuil critique.";
                      break;

                      case 'grey':
                      echo "Qualité de l'air <strong>bonne</strong>. <br/> 
                            Concentrations des éléments toxiques contenus
                            dans l'air <strong>en dessous</strong> du seuil critique.";
                      break;

                    default:
                      # code...
                      break;
                  }
                ?>
                </span>
            </div>
            <div class="legend">
                <div class="level bg-red"></div><div class="level bg-orange"></div><div class="level bg-green"></div>
            </div>
        </section>
    </a>
    <a href="/Hackathon/code/index.php/detail_feu">
        <section>
            <div class="info">
                <h1><img src="/Hackathon/code/img/fire_<?php echo $niveauFeu; ?>.png" class="<?php echo $niveauFeu; ?>"> Risque d'incendie</h1>
                <span class="description"><a href="/Hackathon/code/index.php/detail_feu"><i class="fa fa-info-circle infolink" aria-hidden="true"></i></a>Risque d'incendie élevé, faire un feu est interdit.</span>
            </div>
            <div class="legend">
                <div class="level bg-red">
                  
                </div>
                <div class="level bg-orange">
                
                </div>
                <div class="level bg-yellow">
                
                </div>
                <div class="level bg-green">
                
                </div>
            </div>
        </section>
      </a>
      <a href="/Hackathon/code/index.php/detail_eau">
        <section>
            <div class="info">
                <h1><img src="/Hackathon/code/img/swim_<?php echo $niveauBaignade ?>.png" id="no-border" class="<?php echo $niveauBaignade ?>"> Baignade</h1>
                <span class="description"><a href="/Hackathon/code/index.php/detail_eau"><i class="fa fa-info-circle infolink" aria-hidden="true"></i></a>Les indices de pollution de l'eau sont faibles, la baignade ne présente aucun risque.</span>
            </div>
            <div class="legend">
                <div class="level bg-red">
                  
                </div>
                <div class="level bg-orange">
                  
                </div>
                <div class="level bg-yellow">
                  
                </div>
                <div class="level bg-green">
                  
                </div>
            </div>
        </section>
      </a>
  </div>
<?php $contents = ob_get_clean(); ?>

<?php ob_start(); ?>
    <script>
      // Note: This example requires that you consent to location sharing when 9999999
      // prompted by your browser. If you see the error "The Geolocation service
      // failed.", it means you probably did not give permission for the browser to
      // locate you.

      function initMap() {

        var map = new google.maps.Map(document.getElementById('map'), {
          center: {lat: -34.397, lng: 150.644},
          fullscreenControl: false,
          zoom: 14
        });

        // Try HTML5 geolocation.
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function(position) {
            var pos = {
              lat: position.coords.latitude,
              lng: position.coords.longitude
            };

            map.setCenter(pos);

            var marker = new google.maps.Marker({
              map: map,
              draggable: true,
              animation: google.maps.Animation.DROP,
              position: pos
            });

            var cityCircle = new google.maps.Circle({
              strokeColor: '#2220e2',
              strokeOpacity: 0.5,
              strokeWeight: 2,
              fillColor: '#4285f4',
              fillOpacity: 0.2,
              map: map,
              center: pos,
              radius: 1700
            });
          }, function() {
            handleLocationError(true, infoWindow, map.getCenter());
          });
        } else {
          // Browser doesn't support Geolocation
          handleLocationError(false, infoWindow, map.getCenter());
        }

        //alert(radius);
      }

      function handleLocationError(browserHasGeolocation, infoWindow, pos) {
        infoWindow.setPosition(pos);
        infoWindow.setContent(browserHasGeolocation ?
                              'Error: The Geolocation service failed.' :
                              'Error: Your browser doesn\'t support geolocation.');
      }

    </script>
    <script async defer
      src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBmWNGCwrowebt-qvmIr1wa64NsNGjd15Q&callback=initMap">
    </script>

    <script>
      $(document).ready(function() {
        $('.js-scrollTo').on('click', function() { // Au clic sur un élément
          var page = $(this).attr('href'); // Page cible
          var speed = 600; // Durée de l'animation (en ms)
          $('html, body').animate( { scrollTop: $(page).offset().top }, speed ); // Go
          return false;
        });
      });
    </script>
    <div id="Commune"></div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script>
        $.ajax({
            url: "https://geoip-db.com/jsonp",
            jsonpCallback: "callback",
            dataType: "jsonp",
            success: function( location ) {
                $('#country').html(location.country_name);
                $('#state').html(location.state);
                $('#city').html(location.city);
                $('#latitude').html(location.latitude);
                $('#longitude').html(location.longitude);
                $('#ip').html(location.IPv4);  
                
                var Ville = location.city;
                var Long = location.latitude;
                var Lat = location.longitude;

                $('#Commune').load('/hackathon/code/Ajax/Definie_Ville.php #maj',{Ajax_Ville:Ville,Ajax_Long:Long,Ajax_Lat:Lat}); }
        });     
    </script>

    
  
<?php $scripts = ob_get_clean(); ?>