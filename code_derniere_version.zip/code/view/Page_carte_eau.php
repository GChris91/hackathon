<html lang="fr">
	<head>
		
		<title>BLALALA</title>
		
		<meta charset="utf-8" />
		
		<link rel="stylesheet" href="css/test.css">
	</head>
	<body>
	<p>
	<?php 
		echo qualification_baignade("Anse Vata");
	?>	
	</p>	
	</body>
</html>